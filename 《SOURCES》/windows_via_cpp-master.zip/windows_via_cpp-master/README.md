# WindowsViaCPP
Source Code of the Book Windows Via C/C++ By Jeffrey Richter And Christopher Nasarre

---
## Requirements
* Microsoft Visual Studio 2008

## Summary
Get the preeminent guide to programming application for Windows with C or C++. Programming Applications for Microsoft Windows is a classic book (formerly titled Advanced Windows, Third Edition) and is now fully updated for Windows Vista and Windows Server 2008.

## Linking
* [http://www.wintellect.com/devcenter/paulballard/windows-via-cc-by-jeffrey-richter-and-christopher-nasarre](http://www.wintellect.com/devcenter/paulballard/windows-via-cc-by-jeffrey-richter-and-christopher-nasarre "Windows Via C/C++ By Jeffrey Richter And Christopher Nasarre")

## Picture
![Windows Via C/C++ By Jeffrey Richter And Christopher Nasarre](http://i.imgur.com/4N1RBBH.jpg)