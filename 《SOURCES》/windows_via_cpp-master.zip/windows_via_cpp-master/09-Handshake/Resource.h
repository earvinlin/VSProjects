//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Handshake.rc
//
#define IDC_STATIC              (-1)     // all static controls
#define IDD_HANDSHAKE                   101
#define IDI_HANDSHAKE                   102
#define IDC_REQUEST                     1000
#define IDC_RESULT                      1001
#define IDC_SUBMIT                      1002

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        103
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1004
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
